from django.apps import AppConfig


class PartTimeJobConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'part_time_job'
